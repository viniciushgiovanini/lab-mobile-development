import 'package:flutter/material.dart';
import 'Jogo.dart';

void main() {
  runApp(MaterialApp(
    home: Jogo(),
    debugShowCheckedModeBanner: false,
  ));
}
